/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   ft_strtrim.c                                       :+:    :+:            */
/*                                                     +:+                    */
/*   By: nneveu <nneveu@student.codam.nl>             +#+                     */
/*                                                   +#+                      */
/*   Created: 2019/12/09 16:49:30 by nneveu         #+#    #+#                */
/*   Updated: 2019/12/12 15:15:47 by nneveu        ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <stdlib.h>
#include <stdio.h>

int		ft_strlen_beg(char const *s1, char const *set)
{
	int	i;
	int	i2;

	i = 0;
	i2 = 0;
	while (s1[i] != '\0')
	{
		if (s1[i] == set[i2])
		{
			i++;
			i2 = 0;
		}
		if (s1[i] != set[i2])
			i2++;
		if (set[i2] == '\0')
			break ;
	}
	return (i);
}

int		ft_strlen_end(char const *s1, char const *set)
{
	int	i2;
	int	i3;

	i2 = 0;
	i3 = ft_strlen(s1) - 1;
	while (i3 != 0)
	{
		if (s1[i3] == set[i2])
		{
			i3--;
			i2 = 0;
		}
		if (s1[i3] != set[i2])
			i2++;
		if (set[i2] == '\0')
			break ;
	}
	return (i3);
}

char	*ft_strtrim(char const *s1, char const *set)
{
	int		i;
	int		len;
	char	*res;

	i = 0;
	if (s1 == NULL || set == NULL)
		return (NULL);
	len = (ft_strlen_end(s1, set) - ft_strlen_beg(s1, set) + 1);
	if (ft_strlen_beg(s1, set) > ft_strlen_end(s1, set))
		return (ft_calloc(1, 1));
	res = ft_substr(s1, ft_strlen_beg(s1, set), len);
	return (res);
}
